/**
 * AUTHOR: Lucas Viana Vilela
 * NO.USP: 10748409
 */

#include <stdio.h>

#ifndef JOIN_H
#define JOIN_H

void nested_loop_join(char *vehiclesFilename, char *linesFilename);

void single_loop_join(char *vehiclesFilename, char *linesFilename, char* linesBtreeFilename);

void sorted_interpolation_join(char *vehiclesFilename, char *linesFilename);

#endif
