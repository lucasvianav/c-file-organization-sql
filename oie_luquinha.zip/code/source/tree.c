/** AUTHORS:
 * Lucas Viana Vilela 10748409
 * Stéfane Tame Monteiro Oliveira 10829970
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "./b-tree-struct.c"
#include "../headers/tree.h"
#include "../headers/util.h"
#include "../headers/vehicles.h"
#include "../headers/lines.h"

//consideracoes a fazer depois: acho q dá pra evitar fazer um monte de fread se utilizar fseek em alguns casos, pois eu nao preciso de todas informacoes que tá lendo
// o índice árvore-B também não deve considerar a possibilidade de valores de chave repetidos
//  manipulação do arquivo  de  índice  árvore-B  deve  ser  feita  em  disco,  de  acordo  com  o  conteúdo ministrado em sala de aula.
	

//search(header.noRaiz, valor_int, achou_RRN, achou_POS, achou_Pr)
//incluir o parametro que envia o Pr (ponteiro para arquivo binario veiculo/linha) certo 
ALGO search(RRN, KEY, FOUND_RRN, FOUND_POS){
	if (RRN == NIL){ //RRN == -1 
		return NOT FOUND
	}
	else{
		read page RRN into PAGE //leia o bloco apontado por RRN na variavel PAGE

		look through PAGE for KEY, setting POS equal to the position where KEY occurs or should occur
		//pesquisa a página procurando a chave de busca

		if(KEY was found){
			FOUND_RRN :=RRN //RRN corrente contém a chave
			FOUND_POS :=POS
			return FOUND
		else{
			//procura a chave de busca no nó filho usando o RRN para a página apropriada
			return (search(PAGE.CHILD[POS], KEY, FOUND_RRN, FOUND_POS))
		}
	}
}

ALGO split(I_KEY, I_RRN, PAGE, PROMO_KEY, PROMO_R_CHILD, NEWPAGE){
	copy all keys and pointers from PAGE into a working page that can hold one extra key and child

	insert I_KEY and I_RRN into their proper place in the working page

	allocate and initialize a new page in the B-tree file to hold NEWPAGE

	set PROMO_KEY to the value of middle key, which will be promoted after the split

	set PROMO_R_CHILD to RRN of NEWPAGE

	copy keys and child pointers preceding PROMO_KEY from the working page to PAGE

	copy keys and child pointers following PROMO_KEY from the working page to NEWPAGE
}

ALGO insert(CURRENT_RRN, KEY, PROMO_R_CHILD, PROMO_KEY){
	if (CURRENT_RRN == NIL){ //construção a partir das folhas (bottom)
		PROMO_KEY = KEY
		PROMO_R_CHILD = NIL
		return PROMOTION 
	}      
	else{  //se a página não é um nó folha, a função é chamada recursivamente até que ela encontre uma KEY ou chegue o nó folha
		read page at CURRENT_RRN into PAGE
		search for KEY in PAGE, setting POS to be equal to the position where KEY occurs or should occur
		//pesquisa a página procurando a chave de busca
		
		if (KEY was found){
			issue error message indicating duplicate key
			return ERRO //chave de busca já existe
		}

		//a chave de busca não foi encontrada, portanto procura a chave de busca no nó filho
		RETURN_VALUE = insert ( PAGE.CHILD[POS], KEY, P_B_RRN, P_B_KEY)

		if (RETURN_VALUE == NO PROMOTION or ERROR){
			return RETURN_VALUE
		else if (there is space in PAGE for P_B_KEY){
			insert P_B_KEY and P_B_RRN in PAGE
			return NO PROMOTION //inserção sem particionamento
		else{ //inserção com particionamento, indicando chave promovida
			split (P_B_KEY, P_B_RRN, PAGE, PROMO_KEY, PROMO_R_CHILD, NEWPAGE)
			write PAGE to file at CURRENT_RRN
			write NEWPAGE to file at RRN PROMO_R_CHILD
			return PROMOTION
		}
	}
}

void create_tree_vehicle(char *arquivoVeiculo, char *arquivoArvore){
	FILE *arq1, *arq2;
	vehicle_header header;
    vehicle_register data;
    tree_header headerT; // = (tree_header *)malloc(sizeof(tree_header));
    tree_page page;
    int prefixo_int;

    headerT.status = "0";
    headerT.noRaiz = -1;
    header.RRNproxNo = 1; 
    for(int i = 0; i < 68; i++){
    	header.lixo[i] = "@"
    }

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "wb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }

	// if the file is inconsistent, raise error
    fread(&header.status, sizeof(char), 1, arq1);
    if(header.status == '0'){ raise_error(""); }

    // reads the header's byteProxReg and nroRegistros
    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
    fread(&header.nroRegistros, sizeof(int), 1, arq1);

    // if there are no registers, raises error
    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

    // reads the header's remaining fields
    fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
    fread(header.descrevePrefixo, sizeof(char), 18, arq1);
    fread(header.descreveData, sizeof(char), 35, arq1);
    fread(header.descreveLugares, sizeof(char), 42, arq1);
    fread(header.descreveLinha, sizeof(char), 26, arq1);
    fread(header.descreveModelo, sizeof(char), 17, arq1);
    fread(header.descreveCategoria, sizeof(char), 20, arq1);


    //insere o cabeçalho da arvore
    fwrite(headerT.status, sizeof(char), 1, arq2);
    fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);
    fwrite(headerT.lixo, sizeof(char), 68, arq2);


    // reads and inserts each register
    int index = 0;
    while(index < header.nroRegistros){
        // reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // if the current register was removed, it'll not be inserted
        if(data.removido == '0'){ 
            fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
            continue; 
        }

        // reads the current register's remaining fixed size fields
        fread(data.prefixo, sizeof(char), 5, arq1);
        fread(data.data, sizeof(char), 10, arq1);
        fread(&data.quantidadeLugares, sizeof(int), 1, arq1);
        fread(&data.codLinha, sizeof(int), 1, arq1);

        // reads the current register's "modelo" field (variable size)
        fread(&data.tamanhoModelo, sizeof(int), 1, arq1);
        data.modelo = (char *)malloc(sizeof(char) * data.tamanhoModelo);
        fread(data.modelo, sizeof(char), data.tamanhoModelo, arq1);

        // reads the current register's "categoria" field (variable size)
        fread(&data.tamanhoCategoria, sizeof(int), 1, arq1);
        data.categoria = (char *)malloc(sizeof(char) * data.tamanhoCategoria);
        fread(data.categoria, sizeof(char), data.tamanhoCategoria, arq1);

        // gets formatted date or null message
        char *date = data.data[0] != '\0' ? format_date(data.data) : "campo com valor nulo";
        

        // insere no arquivo 2 a arvore
        prefixo_int = convertePrefixo(data.prefixo);

        // PROMO_R_CHILD E PROMO_KEY (?)
        insert(headerT.noRaiz, prefixo_int, PROMO_R_CHILD, PROMO_KEY);

        //atualizar o headerT.noRaiz
        fseek(arq2, 1, SEEK_SET);
        headerT.noRaiz = PROMO_R_CHILD; //(?)
        headerT.RRNproxNo = PROMO_R_CHILD + 1; //(?) 
    	fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    	fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);


        // frees allocated strings
        free(data.modelo);
        free(data.categoria);

        // increments index
        index++;
    }


    // MUDAR O STATUS PARA 1
    fseek(arq1, 0, SEEK_SET);
    headerT.status = "1";
    fwrite(headerT.status, sizeof(char), 1, arq2);


    fclose(arq1);
    fclose(arq2);
}

void create_tree_line(char *arquivoVeiculo, char *arquivoArvore){
	FILE *arq1, *arq2;
	line_header header;
    line_register data;
    tree_header headerT; // = (tree_header *)malloc(sizeof(tree_header));
    tree_page page;
    int prefixo_int;

    headerT.status = "0";
    headerT.noRaiz = -1;
    header.RRNproxNo = 1; 
    for(int i = 0; i < 68; i++){
    	header.lixo[i] = "@"
    }

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "wb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }

	// if the file is inconsistent, raise error
    fread(&header.status, sizeof(char), 1, arq1);
    if(header.status == '0'){ raise_error(""); }

    // reads the header's byteProxReg and nroRegistros
    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
    fread(&header.nroRegistros, sizeof(int), 1, arq1);

    // if there are no registers, raises error
    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

    // reads the header's remaining fields
    fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
    fread(header.descreveCodigo, sizeof(char), 15, arq1);
    fread(header.descreveCartao, sizeof(char), 13, arq1);
    fread(header.descreveNome, sizeof(char), 13, arq1);
    fread(header.descreveCor, sizeof(char), 24, arq1);

    //insere o cabeçalho da arvore
    fwrite(headerT.status, sizeof(char), 1, arq2);
    fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);
    fwrite(headerT.lixo, sizeof(char), 68, arq2);


    // reads and prints each register
    int index = 0;
    while(index < header.nroRegistros){
        // reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // if the current register was removed, it'll not be printed
        if(data.removido == '0'){ 
            fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
            continue; 
        }

        // reads the current register's remaining fixed size fields
        fread(&data.codLinha, sizeof(int), 1, arq1);
        fread(&data.aceitaCartao, sizeof(char), 1, arq1);

        // reads the current register's "nomeLinha" field (variable size)
        fread(&data.tamanhoNome, sizeof(int), 1, arq1);
        data.nomeLinha = (char *)malloc(sizeof(char) * data.tamanhoNome);
        fread(data.nomeLinha, sizeof(char), data.tamanhoNome, arq1);

        // reads the current register's "corLinha" field (variable size)
        fread(&data.tamanhoCor, sizeof(int), 1, arq1);
        data.corLinha = (char *)malloc(sizeof(char) * data.tamanhoCor);
        fread(data.corLinha, sizeof(char), data.tamanhoCor, arq1);
        

        // insere no arquivo 2 a arvore

        // PROMO_R_CHILD E PROMO_KEY (?)
        insert(headerT.noRaiz, data.codLinha, PROMO_R_CHILD, PROMO_KEY);

        //atualizar o headerT.noRaiz
        fseek(arq2, 1, SEEK_SET);
        headerT.noRaiz = PROMO_R_CHILD; //(?)
        headerT.RRNproxNo = PROMO_R_CHILD + 1; //(?) 
    	fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    	fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);


        // frees allocated strings
        free(data.nomeLinha);
        free(data.corLinha);

        // increments index
        index++;
    }


    // MUDAR O STATUS PARA 1
    fseek(arq1, 0, SEEK_SET);
    headerT.status = "1";
    fwrite(headerT.status, sizeof(char), 1, arq2);


    fclose(arq1);
    fclose(arq2);
}

void search_tree_vehicle(char *arquivoVeiculo, char *arquivoArvore, char *prefixo, char *valor){
	//converte prefixo para poder encontrar a chave
	// A manipulação do arquivo de índice árvore-B deve ser feita em disco, de acordo com o conteúdo ministrado em sala de aula.
	//Falha no processamento do arquivo.

	FILE *arq1, *arq2;
	vehicle_header header;
    vehicle_register data;
    tree_header headerT;
    int valor_int;

    valor_int = convertePrefixo(valor);

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "rb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }


	// procura na arvore
	fread(&headerT.status, sizeof(char), 1, arq2);
    if(headerT.status == '0'){ raise_error(""); }

    fread(&header.noRaiz, sizeof(int), 1, arq2);

	if(search(header.noRaiz, valor_int, achou_RRN, achou_POS, achou_Pr)){
		// if the file is inconsistent, raise error
	    fread(&header.status, sizeof(char), 1, arq1);
	    if(header.status == '0'){ raise_error(""); }

	    // reads the header's byteProxReg and nroRegistros
	    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
	    fread(&header.nroRegistros, sizeof(int), 1, arq1);

	    // if there are no registers, raises error
	    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

	    // reads the header's remaining fields
	    fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
	    fread(header.descrevePrefixo, sizeof(char), 18, arq1);
	    fread(header.descreveData, sizeof(char), 35, arq1);
	    fread(header.descreveLugares, sizeof(char), 42, arq1);
	    fread(header.descreveLinha, sizeof(char), 26, arq1);
	    fread(header.descreveModelo, sizeof(char), 17, arq1);
	    fread(header.descreveCategoria, sizeof(char), 20, arq1);

		fseek(arq1, achou_Pr, SEEK_SET);

		// reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // reads the current register's remaining fixed size fields
        fread(data.prefixo, sizeof(char), 5, arq1);
        fread(data.data, sizeof(char), 10, arq1);
        fread(&data.quantidadeLugares, sizeof(int), 1, arq1);
        fread(&data.codLinha, sizeof(int), 1, arq1);

        // reads the current register's "modelo" field (variable size)
        fread(&data.tamanhoModelo, sizeof(int), 1, arq1);
        data.modelo = (char *)malloc(sizeof(char) * data.tamanhoModelo);
        fread(data.modelo, sizeof(char), data.tamanhoModelo, arq1);

        // reads the current register's "categoria" field (variable size)
        fread(&data.tamanhoCategoria, sizeof(int), 1, arq1);
        data.categoria = (char *)malloc(sizeof(char) * data.tamanhoCategoria);
        fread(data.categoria, sizeof(char), data.tamanhoCategoria, arq1);

		// gets formatted date or null message
        char *date = data.data[0] != '\0' ? format_date(data.data) : "campo com valor nulo";
        
        // prints the current register's fields
        print_string_field(header.descrevePrefixo, 18, data.prefixo, 5);
        print_string_field(header.descreveModelo, 17, data.modelo, data.tamanhoModelo);
        print_string_field(header.descreveCategoria, 20, data.categoria, data.tamanhoCategoria);
        print_string_field(header.descreveData, 35, date, strlen(date));
        print_int_field(header.descreveLugares, 42, data.quantidadeLugares);

        // prints newline
        printf("\n");

        // frees allocated strings
        free(data.modelo);
        free(data.categoria);
        if(data.data[0] != '\0' ){ free(date); }
	}
	else{
		printf("Registro inexistente.\n");
	}

    fclose(arq1);
    fclose(arq2);
}

void search_tree_line(char *arquivoVeiculo, char *arquivoArvore, char *prefixo, int valor){
	// A manipulação do arquivo de índice árvore-B deve ser feita em disco, de acordo com o conteúdo ministrado em sala de aula.
	//Falha no processamento do arquivo.

	FILE *arq1, *arq2;
	line header;
    line_register data;
    tree_header headerT;

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "wb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }


	// procura na arvore
	fread(&headerT.status, sizeof(char), 1, arq2);
    if(headerT.status == '0'){ raise_error(""); }

    fread(&header.noRaiz, sizeof(int), 1, arq2);

	if(search(header.noRaiz, valor_int, achou_RRN, achou_POS, achou_Pr)){
		// if the file is inconsistent, raise error
	    fread(&header.status, sizeof(char), 1, arq1);
	    if(header.status == '0'){ raise_error(""); }

	    // reads the header's byteProxReg and nroRegistros
	    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
	    fread(&header.nroRegistros, sizeof(int), 1, arq1);

	    // if there are no registers, raises error
	    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

	    // reads the header's remaining fields
	    fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
	    fread(header.descreveCodigo, sizeof(char), 15, arq1);
	    fread(header.descreveCartao, sizeof(char), 13, arq1);
	    fread(header.descreveNome, sizeof(char), 13, arq1);
	    fread(header.descreveCor, sizeof(char), 24, arq1);

		fseek(arq1, achou_Pr, SEEK_SET);

		// reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // if the current register was removed, it'll not be printed
        if(data.removido == '0'){ 
            fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
            continue; 
        }

        // reads the current register's remaining fixed size fields
        fread(&data.codLinha, sizeof(int), 1, arq1);
        fread(&data.aceitaCartao, sizeof(char), 1, arq1);

        // reads the current register's "nomeLinha" field (variable size)
        fread(&data.tamanhoNome, sizeof(int), 1, arq1);
        data.nomeLinha = (char *)malloc(sizeof(char) * data.tamanhoNome);
        fread(data.nomeLinha, sizeof(char), data.tamanhoNome, arq1);

        // reads the current register's "corLinha" field (variable size)
        fread(&data.tamanhoCor, sizeof(int), 1, arq1);
        data.corLinha = (char *)malloc(sizeof(char) * data.tamanhoCor);
        fread(data.corLinha, sizeof(char), data.tamanhoCor, arq1);
        
        // gets formatted card status
        char *card_status = format_card(data.aceitaCartao);

        // prints the current register's fields
        print_int_field(header.descreveCodigo, 15, data.codLinha);
        print_string_field(header.descreveNome, 13, data.nomeLinha, data.tamanhoNome);
        print_string_field(header.descreveCor, 24, data.corLinha, data.tamanhoCor);
        print_string_field(header.descreveCartao, 13, card_status, strlen(card_status));

        // prints newline
        printf("\n");

        // frees allocated strings
        free(data.nomeLinha);
        free(data.corLinha);
	}
	else{
		printf("Registro inexistente.\n");
	}

    fclose(arq1);
    fclose(arq2);
}