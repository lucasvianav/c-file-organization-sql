/** AUTHORS:
 * Lucas Viana Vilela 10748409
 * Stéfane Tame Monteiro Oliveira 10829970
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "./b-tree-struct.c"
#include "../headers/tree.h"
#include "../headers/util.h"
#include "../headers/vehicles.h"
#include "../headers/lines.h"

//stefane
//consideracoes a corrigir depois: 
//1. terminar a funcao insert no else e fazer a funcao split
//2. algumas variaveis que estao sendo utilizadas nas funcoes da arvore (ex: page.C4) estao vazias, mas to considerando que elas existem, o que resulta em segmentation fault 
//3. em algumas chamadas de funcoes da arvore, os parametros nao estao sendo definidos
	
int search(int RRN, int KEY, int FOUND_RRN, int FOUND_POS, long long FOUND_PON, FILE ARQ){
    //RRN -> página a ser pesquisada
    //KEY-> chave sendo procurada
    //FOUND_RRN -> página que contém a chave
    //FOUND_POS -> posição da chave na página
    //FOUND_PON -> ponteiro que indica onde esta o registro no arquivo vehicle.bin ou line.bin
    //FILE -> arquivo arvore.bin

    tree_page page;

	if (RRN == -1){ //RRN == -1 
		return 0;
	}
	else{
        fseek(ARQ, RRN, SEEK_SET);
        fread(page.folha, sizeof(char), 1, ARQ);
        fread(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
        fread(page.RRNdoNo, sizeof(int), 1, ARQ);
        fread(page.P1, sizeof(int), 1, ARQ);
        fread(page.C1, sizeof(int), 1, ARQ);
        fread(page.Pr1, sizeof(long long), 1, ARQ);
        fread(page.P2, sizeof(int), 1, ARQ);
        fread(page.C2, sizeof(int), 1, ARQ);
        fread(page.Pr2, sizeof(long long), 1, ARQ);
        fread(page.P3, sizeof(int), 1, ARQ);
        fread(page.C3, sizeof(int), 1, ARQ);
        fread(page.Pr3, sizeof(long long), 1, ARQ);
        fread(page.P4, sizeof(int), 1, ARQ);
        fread(page.C4, sizeof(int), 1, ARQ);
        fread(page.Pr4, sizeof(long long), 1, ARQ);
        fread(page.P5, sizeof(int), 1, ARQ);

        if (KEY < C1){
            return (search(page.P1, KEY, FOUND_RRN, FOUND_POS, FOUND_PON, ARQ))
        }
        else if(KEY == page.C1){
            FOUND_RRN = RNN;
            FOUND_POS = 1;
            FOUND_PON = page.Pr1;
            return 1;
        }
        else if ((C1 < KEY) && (KEY < C2)){
            return (search(page.P2, KEY, FOUND_RRN, FOUND_POS, FOUND_PON, ARQ))
        }
        else if(KEY == page.C2){
            FOUND_RRN = RNN;
            FOUND_POS = 1;
            FOUND_PON = page.Pr2;
            return 1;
        }
        else if ((C2 < KEY) && (KEY < C3)){
            return (search(page.P3, KEY, FOUND_RRN, FOUND_POS, FOUND_PON, ARQ))
        }
        else if(KEY == page.C3){
            FOUND_RRN = RNN;
            FOUND_POS = 1;
            FOUND_PON = page.Pr3;
            return 1;
        }
        else if ((C3 < KEY) && (KEY < C4)){
            return (search(page.P4, KEY, FOUND_RRN, FOUND_POS, FOUND_PON, ARQ))
        }
        else if(KEY == page.C4){
            FOUND_RRN = RNN;
            FOUND_POS = 1;
            FOUND_PON = page.Pr4;
            return 1;
        }
        else if (C4 < KEY){
            return (search(page.P5, KEY, FOUND_RRN, FOUND_POS, FOUND_PON, ARQ))
        }
	}
}

void split(I_KEY, I_RRN, PAGE, PROMO_KEY, PROMO_R_CHILD, NEWPAGE){
    //I_KEY -> nova chave a ser inserida
    //I_RRN-> filho a direita da nova chave a ser inserida
    //PAGE -> página de disco corrente
    //PROMO_KEY -> chave promovida
    //PROMO_R_CHILD -> filho a direita da chave promovida
    //NEWPAGE -> nova página de disco

    int keys[4], ps[5], prs[4];

	copy all keys and pointers from PAGE into a working page that can hold one extra key and child

	insert I_KEY and I_RRN into their proper place in the working page

	allocate and initialize a new page in the B-tree file to hold NEWPAGE

	set PROMO_KEY to the value of middle key, which will be promoted after the split

	set PROMO_R_CHILD to RRN of NEWPAGE

	copy keys and child pointers preceding PROMO_KEY from the working page to PAGE

	copy keys and child pointers following PROMO_KEY from the working page to NEWPAGE
}

int insert(int CURRENT_RRN, int KEY, int PROMO_R_CHILD, int PROMO_KEY, long long PON, FILE ARQ){
    //CURRENT_RRN -> página a ser pesquisada
    //KEY -> chave a ser inserida
    //PROMO_R_CHILD ->  RRN filho direito 
    //PROMO_KEYPROMO_KEY -> chave promovida
    //PON -> ponteiro que indica onde esta o registro no arquivo vehicle.bin ou line.bin
    //FILE -> arquivo arvore.bin

    tree_page page;

	if (CURRENT_RRN == -1){
		PROMO_KEY = KEY
		PROMO_R_CHILD = -1
		return 1 //PROMOTION
	}      
	else{ 
        fseek(ARQ, CURRENT_RRN, SEEK_SET);
        fread(page.folha, sizeof(char), 1, ARQ); 
        fread(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
        fread(page.RRNdoNo, sizeof(int), 1, ARQ);
        fread(page.P1, sizeof(int), 1, ARQ);
        fread(page.C1, sizeof(int), 1, ARQ);
        fread(page.Pr1, sizeof(long long), 1, ARQ);
        fread(page.P2, sizeof(int), 1, ARQ);
        fread(page.C2, sizeof(int), 1, ARQ);
        fread(page.Pr2, sizeof(long long), 1, ARQ);
        fread(page.P3, sizeof(int), 1, ARQ);
        fread(page.C3, sizeof(int), 1, ARQ);
        fread(page.Pr3, sizeof(long long), 1, ARQ);
        fread(page.P4, sizeof(int), 1, ARQ);
        fread(page.C4, sizeof(int), 1, ARQ);
        fread(page.Pr4, sizeof(long long), 1, ARQ);
        fread(page.P5, sizeof(int), 1, ARQ);
		
		if ((KEY == C1) || (KEY == C2) || (KEY == C3) || (KEY == C4)){
            raise_error("");
            return ERROR
        }
        else if (KEY < C1){
            RETURN_VALUE = insert (page.P1, KEY, PROMO_R_CHILD, PROMO_KEY, PON, ARQ)
        }
        else if ((C1 < KEY) && (KEY < C2)){
            RETURN_VALUE = insert (page.P2, KEY, PROMO_R_CHILD, PROMO_KEY, PON, ARQ)
        }
        else if ((C2 < KEY) && (KEY < C3)){
            RETURN_VALUE = insert (page.P3, KEY, PROMO_R_CHILD, PROMO_KEY, PON, ARQ)
        }
        else if ((C3 < KEY) && (KEY < C4)){
            RETURN_VALUE = insert (page.P4, KEY, PROMO_R_CHILD, PROMO_KEY, PON, ARQ)
        }
        else if (C4 < KEY){
            RETURN_VALUE = insert (page.P4, KEY, PROMO_R_CHILD, PROMO_KEY, PON, ARQ)
        }

        if ((RETURN_VALUE == NO_PROMOTION) or (RETURN_VALUE == ERROR)){
            return RETURN_VALUE
        }
        else if (page.nroChavesIndexadas < 4){
            if(KEY < C1){
                page.nroChavesIndexadas++; 
                page.P5 = page.P4;
                page.C4 = page.C3;
                page.Pr4 = page.Pr3;
                page.P4 = page.P3;
                page.C3 = page.C2;
                page.Pr3 = page.Pr2;
                page.P3 = page.P2;
                page.C2 = page.C1;
                page.Pr2 = page.Pr1;
                page.P2 = page.P1;
                page.C1 = KEY;
                page.Pr1 = PON;
                page.P1 = -1;

                fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
                fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
                fseek(ARQ, 4, SEEK_CUR);
                fwrite(page.P1, sizeof(int), 1, ARQ);
                fwrite(page.C1, sizeof(int), 1, ARQ);
                fwrite(page.Pr1, sizeof(long long), 1, ARQ);
                fwrite(page.P2, sizeof(int), 1, ARQ);
                fwrite(page.C2, sizeof(int), 1, ARQ);
                fwrite(page.Pr2, sizeof(long long), 1, ARQ);
                fwrite(page.P3, sizeof(int), 1, ARQ);
                fwrite(page.C3, sizeof(int), 1, ARQ);
                fwrite(page.Pr3, sizeof(long long), 1, ARQ);
                fwrite(page.P4, sizeof(int), 1, ARQ);
                fwrite(page.C4, sizeof(int), 1, ARQ);
                fwrite(page.Pr4, sizeof(long long), 1, ARQ);
                fwrite(page.P5, sizeof(int), 1, ARQ);
            }
            else if((C1 < KEY) && (KEY < C2)){
                page.nroChavesIndexadas++; 
                page.P5 = page.P4;
                page.C4 = page.C3;
                page.Pr4 = page.Pr3;
                page.P4 = page.P3;
                page.C3 = page.C2;
                page.Pr3 = page.Pr2;
                page.P3 = page.P2;
                page.C2 = KEY
                page.Pr2 = PON;
                page.P2 = -1;

                fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
                fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
                fseek(ARQ, 20, SEEK_CUR);
                fwrite(page.P2, sizeof(int), 1, ARQ);
                fwrite(page.C2, sizeof(int), 1, ARQ);
                fwrite(page.Pr2, sizeof(long long), 1, ARQ);
                fwrite(page.P3, sizeof(int), 1, ARQ);
                fwrite(page.C3, sizeof(int), 1, ARQ);
                fwrite(page.Pr3, sizeof(long long), 1, ARQ);
                fwrite(page.P4, sizeof(int), 1, ARQ);
                fwrite(page.C4, sizeof(int), 1, ARQ);
                fwrite(page.Pr4, sizeof(long long), 1, ARQ);
                fwrite(page.P5, sizeof(int), 1, ARQ);
            }
            else if((C2 < KEY) && (KEY < C3)){
                page.nroChavesIndexadas++; 
                page.P5 = page.P4;
                page.C4 = page.C3;
                page.Pr4 = page.Pr3;
                page.P4 = page.P3;
                page.C3 = KEY;
                page.Pr3 = PON;
                page.P3 = -1;

                fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
                fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
                fseek(ARQ, 36, SEEK_CUR);
                fwrite(page.P3, sizeof(int), 1, ARQ);
                fwrite(page.C3, sizeof(int), 1, ARQ);
                fwrite(page.Pr3, sizeof(long long), 1, ARQ);
                fwrite(page.P4, sizeof(int), 1, ARQ);
                fwrite(page.C4, sizeof(int), 1, ARQ);
                fwrite(page.Pr4, sizeof(long long), 1, ARQ);
                fwrite(page.P5, sizeof(int), 1, ARQ);
            }
            else if((C2 < KEY) && (KEY < C3)){
                page.nroChavesIndexadas++; 
                page.P5 = page.P4;
                page.C4 = page.C3;
                page.Pr4 = page.Pr3;
                page.P4 = page.P3;
                page.C3 = KEY;
                page.Pr3 = PON;
                page.P3 = -1;

                fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
                fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
                fseek(ARQ, 36, SEEK_CUR);
                fwrite(page.P3, sizeof(int), 1, ARQ);
                fwrite(page.C3, sizeof(int), 1, ARQ);
                fwrite(page.Pr3, sizeof(long long), 1, ARQ);
                fwrite(page.P4, sizeof(int), 1, ARQ);
                fwrite(page.C4, sizeof(int), 1, ARQ);
                fwrite(page.Pr4, sizeof(long long), 1, ARQ);
                fwrite(page.P5, sizeof(int), 1, ARQ);
            }
            else if(C3 < KEY){
                page.nroChavesIndexadas++; 
                page.P5 = page.P4;
                page.C4 = KEY;
                page.Pr4 = PON;
                page.P4 = -1;

                fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
                fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
                fseek(ARQ, 52, SEEK_CUR);
                fwrite(page.P4, sizeof(int), 1, ARQ);
                fwrite(page.C4, sizeof(int), 1, ARQ);
                fwrite(page.Pr4, sizeof(long long), 1, ARQ);
                fwrite(page.P5, sizeof(int), 1, ARQ);
            }

            return NO_PROMOTION
        }
        else{
            split (P_B_KEY, P_B_RRN, PAGE, PROMO_KEY, PROMO_R_CHILD, NEWPAGE)
            write PAGE to file at CURRENT_RRN
            write NEWPAGE to file at RRN PROMO_R_CHILD
            return PROMOTION
        }
	}
}

void create_tree_vehicle(char *arquivoVeiculo, char *arquivoArvore){
	FILE *arq1, *arq2;
	vehicle_header header;
    vehicle_register data;
    tree_header headerT; // = (tree_header *)malloc(sizeof(tree_header));
    tree_page page;
    int prefixo_int;

    headerT.status = "0";
    headerT.noRaiz = -1;
    header.RRNproxNo = 1; 
    for(int i = 0; i < 68; i++){
    	header.lixo[i] = "@"
    }

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "wb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }

	// if the file is inconsistent, raise error
    fread(&header.status, sizeof(char), 1, arq1);
    if(header.status == '0'){ raise_error(""); }

    // reads the header's byteProxReg and nroRegistros
    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
    fread(&header.nroRegistros, sizeof(int), 1, arq1);

    // if there are no registers, raises error
    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

    // reads the header's remaining fields
    /*fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
    fread(header.descrevePrefixo, sizeof(char), 18, arq1);
    fread(header.descreveData, sizeof(char), 35, arq1);
    fread(header.descreveLugares, sizeof(char), 42, arq1);
    fread(header.descreveLinha, sizeof(char), 26, arq1);
    fread(header.descreveModelo, sizeof(char), 17, arq1);
    fread(header.descreveCategoria, sizeof(char), 20, arq1);*/
    fseek(arq1, 162, SEEK_CUR);


    //insere o cabeçalho da arvore
    fwrite(headerT.status, sizeof(char), 1, arq2);
    fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);
    fwrite(headerT.lixo, sizeof(char), 68, arq2);


    // reads and inserts each register
    int index = 0;
    while(index < header.nroRegistros){
        // reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // if the current register was removed, it'll not be inserted
        if(data.removido == '0'){ 
            fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
            continue; 
        }

        // reads the current register's remaining fixed size fields
        fread(data.prefixo, sizeof(char), 5, arq1);
        /*fread(data.data, sizeof(char), 10, arq1);
        fread(&data.quantidadeLugares, sizeof(int), 1, arq1);
        fread(&data.codLinha, sizeof(int), 1, arq1);

        // reads the current register's "modelo" field (variable size)
        fread(&data.tamanhoModelo, sizeof(int), 1, arq1);
        data.modelo = (char *)malloc(sizeof(char) * data.tamanhoModelo);
        fread(data.modelo, sizeof(char), data.tamanhoModelo, arq1);

        // reads the current register's "categoria" field (variable size)
        fread(&data.tamanhoCategoria, sizeof(int), 1, arq1);
        data.categoria = (char *)malloc(sizeof(char) * data.tamanhoCategoria);
        fread(data.categoria, sizeof(char), data.tamanhoCategoria, arq1);

        // gets formatted date or null message
        char *date = data.data[0] != '\0' ? format_date(data.data) : "campo com valor nulo";*/
        fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
        

        // insere no arquivo 2 a arvore
        prefixo_int = convertePrefixo(data.prefixo);

        // PROMO_R_CHILD E PROMO_KEY E PON (?)
        insert(headerT.noRaiz, prefixo_int, PROMO_R_CHILD, PROMO_KEY, PON, arq2);

        //atualizar o headerT.noRaiz
        fseek(arq2, 1, SEEK_SET);
        headerT.noRaiz = PROMO_R_CHILD; //(?)
        headerT.RRNproxNo = PROMO_R_CHILD + 1; //(?) 
    	fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    	fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);


        // frees allocated strings
        /*free(data.modelo);
        free(data.categoria);*/

        // increments index
        index++;
    }


    // MUDAR O STATUS PARA 1
    fseek(arq1, 0, SEEK_SET);
    headerT.status = "1";
    fwrite(headerT.status, sizeof(char), 1, arq2);


    fclose(arq1);
    fclose(arq2);
}

void create_tree_line(char *arquivoVeiculo, char *arquivoArvore){
	FILE *arq1, *arq2;
	line_header header;
    line_register data;
    tree_header headerT; // = (tree_header *)malloc(sizeof(tree_header));
    tree_page page;
    int prefixo_int;

    headerT.status = "0";
    headerT.noRaiz = -1;
    header.RRNproxNo = 1; 
    for(int i = 0; i < 68; i++){
    	header.lixo[i] = "@"
    }

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "wb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }

	// if the file is inconsistent, raise error
    fread(&header.status, sizeof(char), 1, arq1);
    if(header.status == '0'){ raise_error(""); }

    // reads the header's byteProxReg and nroRegistros
    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
    fread(&header.nroRegistros, sizeof(int), 1, arq1);

    // if there are no registers, raises error
    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

    // reads the header's remaining fields
    /*fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
    fread(header.descreveCodigo, sizeof(char), 15, arq1);
    fread(header.descreveCartao, sizeof(char), 13, arq1);
    fread(header.descreveNome, sizeof(char), 13, arq1);
    fread(header.descreveCor, sizeof(char), 24, arq1);*/
    fseek(arq1, 69, SEEK_CUR);

    //insere o cabeçalho da arvore
    fwrite(headerT.status, sizeof(char), 1, arq2);
    fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);
    fwrite(headerT.lixo, sizeof(char), 68, arq2);


    // reads and prints each register
    int index = 0;
    while(index < header.nroRegistros){
        // reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // if the current register was removed, it'll not be printed
        if(data.removido == '0'){ 
            fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
            continue; 
        }

        // reads the current register's remaining fixed size fields
        fread(&data.codLinha, sizeof(int), 1, arq1);
        /*fread(&data.aceitaCartao, sizeof(char), 1, arq1);

        // reads the current register's "nomeLinha" field (variable size)
        fread(&data.tamanhoNome, sizeof(int), 1, arq1);
        data.nomeLinha = (char *)malloc(sizeof(char) * data.tamanhoNome);
        fread(data.nomeLinha, sizeof(char), data.tamanhoNome, arq1);

        // reads the current register's "corLinha" field (variable size)
        fread(&data.tamanhoCor, sizeof(int), 1, arq1);
        data.corLinha = (char *)malloc(sizeof(char) * data.tamanhoCor);
        fread(data.corLinha, sizeof(char), data.tamanhoCor, arq1);*/
        fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
        


        // PROMO_R_CHILD E PROMO_KEY (?)
        insert(headerT.noRaiz, data.codLinha, PROMO_R_CHILD, PROMO_KEY, PON, arq2);

        //atualizar o headerT.noRaiz
        fseek(arq2, 1, SEEK_SET);
        headerT.noRaiz = PROMO_R_CHILD; //(?)
        headerT.RRNproxNo = PROMO_R_CHILD + 1; //(?) 
    	fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    	fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);


        // frees allocated strings
        /*free(data.nomeLinha);
        free(data.corLinha);*/

        // increments index
        index++;
    }


    // MUDAR O STATUS PARA 1
    fseek(arq1, 0, SEEK_SET);
    headerT.status = "1";
    fwrite(headerT.status, sizeof(char), 1, arq2);


    fclose(arq1);
    fclose(arq2);
}

void search_tree_vehicle(char *arquivoVeiculo, char *arquivoArvore, char *prefixo, char *valor){
	//converte prefixo para poder encontrar a chave
	// A manipulação do arquivo de índice árvore-B deve ser feita em disco, de acordo com o conteúdo ministrado em sala de aula.
	//Falha no processamento do arquivo.

	FILE *arq1, *arq2;
	vehicle_header header;
    vehicle_register data;
    tree_header headerT;
    int valor_int;

    valor_int = convertePrefixo(valor);

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "rb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }


	// procura na arvore
	fread(&headerT.status, sizeof(char), 1, arq2);
    if(headerT.status == '0'){ raise_error(""); }

    fread(&header.noRaiz, sizeof(int), 1, arq2);
    
	if(search(header.noRaiz, valor_int, achou_RRN, achou_POS, achou_Pr, arq2)){
		// if the file is inconsistent, raise error
	    fread(&header.status, sizeof(char), 1, arq1);
	    if(header.status == '0'){ raise_error(""); }

	    // reads the header's byteProxReg and nroRegistros
	    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
	    fread(&header.nroRegistros, sizeof(int), 1, arq1);

	    // if there are no registers, raises error
	    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

	    // reads the header's remaining fields
	    fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
	    fread(header.descrevePrefixo, sizeof(char), 18, arq1);
	    fread(header.descreveData, sizeof(char), 35, arq1);
	    fread(header.descreveLugares, sizeof(char), 42, arq1);
	    fread(header.descreveLinha, sizeof(char), 26, arq1);
	    fread(header.descreveModelo, sizeof(char), 17, arq1);
	    fread(header.descreveCategoria, sizeof(char), 20, arq1);

		fseek(arq1, achou_Pr, SEEK_SET);

		// reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // reads the current register's remaining fixed size fields
        fread(data.prefixo, sizeof(char), 5, arq1);
        fread(data.data, sizeof(char), 10, arq1);
        fread(&data.quantidadeLugares, sizeof(int), 1, arq1);
        fread(&data.codLinha, sizeof(int), 1, arq1);

        // reads the current register's "modelo" field (variable size)
        fread(&data.tamanhoModelo, sizeof(int), 1, arq1);
        data.modelo = (char *)malloc(sizeof(char) * data.tamanhoModelo);
        fread(data.modelo, sizeof(char), data.tamanhoModelo, arq1);

        // reads the current register's "categoria" field (variable size)
        fread(&data.tamanhoCategoria, sizeof(int), 1, arq1);
        data.categoria = (char *)malloc(sizeof(char) * data.tamanhoCategoria);
        fread(data.categoria, sizeof(char), data.tamanhoCategoria, arq1);

		// gets formatted date or null message
        char *date = data.data[0] != '\0' ? format_date(data.data) : "campo com valor nulo";
        
        // prints the current register's fields
        print_string_field(header.descrevePrefixo, 18, data.prefixo, 5);
        print_string_field(header.descreveModelo, 17, data.modelo, data.tamanhoModelo);
        print_string_field(header.descreveCategoria, 20, data.categoria, data.tamanhoCategoria);
        print_string_field(header.descreveData, 35, date, strlen(date));
        print_int_field(header.descreveLugares, 42, data.quantidadeLugares);

        // prints newline
        printf("\n");

        // frees allocated strings
        free(data.modelo);
        free(data.categoria);
        if(data.data[0] != '\0' ){ free(date); }
	}
	else{
		printf("Registro inexistente.\n");
	}

    fclose(arq1);
    fclose(arq2);
}

void search_tree_line(char *arquivoVeiculo, char *arquivoArvore, char *prefixo, int valor){
	// A manipulação do arquivo de índice árvore-B deve ser feita em disco, de acordo com o conteúdo ministrado em sala de aula.
	//Falha no processamento do arquivo.

	FILE *arq1, *arq2;
	line header;
    line_register data;
    tree_header headerT;

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "wb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }


	// procura na arvore
	fread(&headerT.status, sizeof(char), 1, arq2);
    if(headerT.status == '0'){ raise_error(""); }

    fread(&header.noRaiz, sizeof(int), 1, arq2);

	if(search(header.noRaiz, valor_int, achou_RRN, achou_POS, achou_Pr, arq2)){
		// if the file is inconsistent, raise error
	    fread(&header.status, sizeof(char), 1, arq1);
	    if(header.status == '0'){ raise_error(""); }

	    // reads the header's byteProxReg and nroRegistros
	    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
	    fread(&header.nroRegistros, sizeof(int), 1, arq1);

	    // if there are no registers, raises error
	    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

	    // reads the header's remaining fields
	    fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
	    fread(header.descreveCodigo, sizeof(char), 15, arq1);
	    fread(header.descreveCartao, sizeof(char), 13, arq1);
	    fread(header.descreveNome, sizeof(char), 13, arq1);
	    fread(header.descreveCor, sizeof(char), 24, arq1);

		fseek(arq1, achou_Pr, SEEK_SET);

		// reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // if the current register was removed, it'll not be printed
        if(data.removido == '0'){ 
            fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
            continue; 
        }

        // reads the current register's remaining fixed size fields
        fread(&data.codLinha, sizeof(int), 1, arq1);
        fread(&data.aceitaCartao, sizeof(char), 1, arq1);

        // reads the current register's "nomeLinha" field (variable size)
        fread(&data.tamanhoNome, sizeof(int), 1, arq1);
        data.nomeLinha = (char *)malloc(sizeof(char) * data.tamanhoNome);
        fread(data.nomeLinha, sizeof(char), data.tamanhoNome, arq1);

        // reads the current register's "corLinha" field (variable size)
        fread(&data.tamanhoCor, sizeof(int), 1, arq1);
        data.corLinha = (char *)malloc(sizeof(char) * data.tamanhoCor);
        fread(data.corLinha, sizeof(char), data.tamanhoCor, arq1);
        
        // gets formatted card status
        char *card_status = format_card(data.aceitaCartao);

        // prints the current register's fields
        print_int_field(header.descreveCodigo, 15, data.codLinha);
        print_string_field(header.descreveNome, 13, data.nomeLinha, data.tamanhoNome);
        print_string_field(header.descreveCor, 24, data.corLinha, data.tamanhoCor);
        print_string_field(header.descreveCartao, 13, card_status, strlen(card_status));

        // prints newline
        printf("\n");

        // frees allocated strings
        free(data.nomeLinha);
        free(data.corLinha);
	}
	else{
		printf("Registro inexistente.\n");
	}

    fclose(arq1);
    fclose(arq2);
}
