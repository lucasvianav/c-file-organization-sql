/** AUTHORS:
 * Lucas Viana Vilela 10748409
 * Stéfane Tame Monteiro Oliveira 10829970
*/

#define TREE_LENGTH 77

typedef struct {
    char status;
    int noRaiz; // começa com -1
    int RRNproxNo; 
    char lixo[68] //lixo @
} tree_header;

typedef struct {
    char folha;
    int nroChavesIndexadas; //numero maximo: 4 chaves
    int RRNdoNo;
    int P1[4];
    int C1[4];
    long long Pr1[8];
    int P2[4];
    int C2[4];
    long long Pr2[8];
    int P3[4];
    int C3[4];
    long long Pr3[8];
    int P4[4];
    int C4[4];
    long long Pr4[8];
    int P5[4];
} tree_page;

typedef struct {
    tree_header *header;
    tree_register *data;
    int tree_length;
} tree;