#ifndef UTIL_H
#define UTIL_H

void raise_error();
char *read_csv(char *filename);
void binarioNaTela(char *filename);
void scan_quote_string(char *str);

#endif
