#ifndef LINE_H
#define LINE_H

void write_line_bin(char *filename, char *content);
void append_line_bin(char *filename, int no_inputs);
void impressaoL(char *filename);
void buscaL(char *filename, char *campo, char *valor);

#endif