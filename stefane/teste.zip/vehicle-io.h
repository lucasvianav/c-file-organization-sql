#ifndef VEHICLE_H
#define VEHICLE_H

void write_vehicle_bin(char *filename, char *content);
void append_vehicle_bin(char *filename, int no_inputs);
void impressaoV(char *filename);
void buscaV(char *filename, char *campo, char *valor);

#endif