/** AUTHORS:
 * Lucas Viana Vilela 10748409
 * Stéfane Tame Monteiro Oliveira 10829970
*/

#ifndef TREE_H
#define TREE_H

//funcoes da arvore
void create_tree_vehicle(char *arquivoVeiculo, char *arquivoArvore);

void create_tree_line(char *arquivoVeiculo, char *arquivoArvore);

void search_tree_vehicle(char *arquivoVeiculo, char *arquivoArvore, char *prefixo, char *valor);

void search_tree_line(char *arquivoVeiculo, char *arquivoArvore, char *prefixo, int valor);

#endif