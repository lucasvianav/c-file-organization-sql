/** AUTHORS:
 * Lucas Viana Vilela 10748409
 * Stéfane Tame Monteiro Oliveira 10829970
*/

#define TREE_LENGTH 77
#define NO_PROMOTION 0
#define PROMOTION 1
#define ERROR -1

typedef struct {
    char status;
    int noRaiz; // começa com -1
    int RRNproxNo; 
    char lixo[68]; //lixo @
} tree_header;

typedef struct {
    char folha; //0 indica que o nó não é folha e 1 indica que o nó é folha
    int nroChavesIndexadas; //numero maximo: 4 chaves
    int RRNdoNo;
    int P1;
    int C1;
    long long Pr1;
    int P2;
    int C2;
    long long Pr2;
    int P3;
    int C3;
    long long Pr3;
    int P4;
    int C4;
    long long Pr4;
    int P5;
} tree_page;

typedef struct {
    tree_header *header;
    tree_register *data;
    int tree_length;
} tree;