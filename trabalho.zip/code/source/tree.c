/** AUTHORS:
 * Lucas Viana Vilela 10748409
 * Stéfane Tame Monteiro Oliveira 10829970
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "./b-tree-struct.c"
#include "../headers/tree.h"
#include "../headers/util.h"
#include "../headers/vehicles.h"
#include "../headers/lines.h"

//stefane
//consideracoes:
//1. funcao search funcionando
//2. funcao insert e split ainda precisa corrigir o funcionamento
    
int search(int RRN, int KEY, FILE *ARQ){
    tree_page page;

    if (RRN == -1){
        return -1;
    }
    else{
        fseek(ARQ, (RRN+1)*TREE_LENGTH, SEEK_SET);

        fread(&page.folha, sizeof(char), 1, ARQ);
        fread(&page.nroChavesIndexadas, sizeof(int), 1, ARQ);
        fread(&page.RRNdoNo, sizeof(int), 1, ARQ);
        fread(&page.P1, sizeof(int), 1, ARQ);
        fread(&page.C1, sizeof(int), 1, ARQ);
        fread(&page.Pr1, sizeof(long long), 1, ARQ);
        fread(&page.P2, sizeof(int), 1, ARQ);
        fread(&page.C2, sizeof(int), 1, ARQ);
        fread(&page.Pr2, sizeof(long long), 1, ARQ);
        fread(&page.P3, sizeof(int), 1, ARQ);
        fread(&page.C3, sizeof(int), 1, ARQ);
        fread(&page.Pr3, sizeof(long long), 1, ARQ);
        fread(&page.P4, sizeof(int), 1, ARQ);
        fread(&page.C4, sizeof(int), 1, ARQ);
        fread(&page.Pr4, sizeof(long long), 1, ARQ);
        fread(&page.P5, sizeof(int), 1, ARQ);

        if (KEY < page.C1){
            return (search(page.P1, KEY, ARQ));
        }
        else if ((page.C1 < KEY) && ( ((KEY < page.C2) && (page.nroChavesIndexadas > 1)) || ((page.nroChavesIndexadas == 1)))){
            return (search(page.P2, KEY, ARQ));
        }
        else if ((page.C2 < KEY) && ( ((KEY < page.C3) && (page.nroChavesIndexadas > 2)) || ((page.nroChavesIndexadas == 2)))){
            return (search(page.P3, KEY, ARQ));
        }
        else if ((page.C3 < KEY) && ( ((KEY < page.C4) && (page.nroChavesIndexadas > 3)) || ((page.nroChavesIndexadas == 3)))){
            return (search(page.P4, KEY, ARQ));
        }
        else if(page.C4 < KEY && (page.nroChavesIndexadas == 4)){
            return (search(page.P5, KEY, ARQ));
        }
        else{
            return RRN;
        }
    }
}

/*void split(int KEY, int I_RRN, int page, int PROMO_KEY, int PROMO_R_CHILD, int NEWPAGE, long long PON){
    //I_KEY -> nova chave a ser inserida
    //I_RRN-> filho a direita da nova chave a ser inserida
    //PAGE -> página de disco corrente
    //PROMO_KEY -> chave promovida
    //PROMO_R_CHILD -> filho a direita da chave promovida
    //NEWPAGE -> nova página de disco
    tree_page NEWPAGE;

    if(KEY < C1){
        NEWPAGE.C1 = page.C3
        NEWPAGE.Pr1 = page.Pr3
        NEWPAGE.P2 = page.P4
        NEWPAGE.C2 = page.C4
        NEWPAGE.Pr2 = page.Pr4
        NEWPAGE.P3 = page.P5
        
        page.P4 = page.P3;
        page.C3 = page.C2;
        page.Pr3 = page.Pr2;
        page.P3 = page.P2;
        page.C2 = page.C1;
        page.Pr2 = page.Pr1;
        page.P2 = page.P1;
        page.C1 = KEY;
        page.Pr1 = PON;
        page.P1 = -1;

        fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
        fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
        fseek(ARQ, 4, SEEK_CUR);
        fwrite(page.P1, sizeof(int), 1, ARQ);
        fwrite(page.C1, sizeof(int), 1, ARQ);
        fwrite(page.Pr1, sizeof(long long), 1, ARQ);
        fwrite(page.P2, sizeof(int), 1, ARQ);
        fwrite(page.C2, sizeof(int), 1, ARQ);
        fwrite(page.Pr2, sizeof(long long), 1, ARQ);
        fwrite(page.P3, sizeof(int), 1, ARQ);
        fwrite(page.C3, sizeof(int), 1, ARQ);
        fwrite(page.Pr3, sizeof(long long), 1, ARQ);
        fwrite(page.P4, sizeof(int), 1, ARQ);
        fwrite(page.C4, sizeof(int), 1, ARQ);
        fwrite(page.Pr4, sizeof(long long), 1, ARQ);
        fwrite(page.P5, sizeof(int), 1, ARQ);

        fseek(ARQ, 0, SEEK_END);
        fwrite(NEWPAGE.C1, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr1, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.C2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr2, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P3, sizeof(int), 1, ARQ);
    }
    else if((C1 < KEY) && (KEY < C2)){
        NEWPAGE.C1 = page.C3
        NEWPAGE.Pr1 = page.Pr3
        NEWPAGE.P2 = page.P4
        NEWPAGE.C2 = page.C4
        NEWPAGE.Pr2 = page.Pr4
        NEWPAGE.P3 = page.P5

        page.P4 = page.P3;
        page.C3 = page.C2;
        page.Pr3 = page.Pr2;
        page.P3 = page.P2;
        page.C2 = KEY
        page.Pr2 = PON;
        page.P2 = -1;

        fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
        fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
        fseek(ARQ, 20, SEEK_CUR);
        fwrite(page.P2, sizeof(int), 1, ARQ);
        fwrite(page.C2, sizeof(int), 1, ARQ);
        fwrite(page.Pr2, sizeof(long long), 1, ARQ);
        fwrite(page.P3, sizeof(int), 1, ARQ);
        fwrite(page.C3, sizeof(int), 1, ARQ);
        fwrite(page.Pr3, sizeof(long long), 1, ARQ);
        fwrite(page.P4, sizeof(int), 1, ARQ);
        fwrite(page.C4, sizeof(int), 1, ARQ);
        fwrite(page.Pr4, sizeof(long long), 1, ARQ);
        fwrite(page.P5, sizeof(int), 1, ARQ);

        fseek(ARQ, 0, SEEK_END);
        fwrite(NEWPAGE.C1, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr1, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.C2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr2, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P3, sizeof(int), 1, ARQ);
    }
    else if((C2 < KEY) && (KEY < C3)){
        NEWPAGE.C1 = page.C3
        NEWPAGE.Pr1 = page.Pr3
        NEWPAGE.P2 = page.P4
        NEWPAGE.C2 = page.C4
        NEWPAGE.Pr2 = page.Pr4
        NEWPAGE.P3 = page.P5

        page.P4 = page.P3;
        page.C3 = KEY;
        page.Pr3 = PON;
        page.P3 = -1;

        fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
        fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
        fseek(ARQ, 36, SEEK_CUR);
        fwrite(page.P3, sizeof(int), 1, ARQ);
        fwrite(page.C3, sizeof(int), 1, ARQ);
        fwrite(page.Pr3, sizeof(long long), 1, ARQ);
        fwrite(page.P4, sizeof(int), 1, ARQ);
        fwrite(page.C4, sizeof(int), 1, ARQ);
        fwrite(page.Pr4, sizeof(long long), 1, ARQ);
        fwrite(page.P5, sizeof(int), 1, ARQ);

        fseek(ARQ, 0, SEEK_END);
        fwrite(NEWPAGE.C1, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr1, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.C2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr2, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P3, sizeof(int), 1, ARQ);
    }
    else if((C2 < KEY) && (KEY < C3)){
        NEWPAGE.C1 = page.C3
        NEWPAGE.Pr1 = page.Pr3
        NEWPAGE.P2 = page.P4
        NEWPAGE.C2 = page.C4
        NEWPAGE.Pr2 = page.Pr4
        NEWPAGE.P3 = page.P5

        page.P4 = page.P3;
        page.C3 = KEY;
        page.Pr3 = PON;
        page.P3 = -1;

        fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
        fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
        fseek(ARQ, 36, SEEK_CUR);
        fwrite(page.P3, sizeof(int), 1, ARQ);
        fwrite(page.C3, sizeof(int), 1, ARQ);
        fwrite(page.Pr3, sizeof(long long), 1, ARQ);
        fwrite(page.P4, sizeof(int), 1, ARQ);
        fwrite(page.C4, sizeof(int), 1, ARQ);
        fwrite(page.Pr4, sizeof(long long), 1, ARQ);
        fwrite(page.P5, sizeof(int), 1, ARQ);

        fseek(ARQ, 0, SEEK_END);
        fwrite(NEWPAGE.C1, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr1, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.C2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr2, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P3, sizeof(int), 1, ARQ);
    }
    else if((C3 < KEY) && (KEY < C4)){
        NEWPAGE.C1 = KEY
        NEWPAGE.Pr1 = PON
        NEWPAGE.P2 = 
        NEWPAGE.C2 = page.C4
        NEWPAGE.Pr2 = page.Pr4
        NEWPAGE.P3 = page.P5

        fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
        fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
        fseek(ARQ, 52, SEEK_CUR);
        fwrite(page.P4, sizeof(int), 1, ARQ);
        fwrite(page.C4, sizeof(int), 1, ARQ);
        fwrite(page.Pr4, sizeof(long long), 1, ARQ);
        fwrite(page.P5, sizeof(int), 1, ARQ);

        fseek(ARQ, 0, SEEK_END);
        fwrite(NEWPAGE.C1, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr1, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.C2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr2, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P3, sizeof(int), 1, ARQ);
    }
    else if(C4 < KEY){
        NEWPAGE.C1 = page.C4
        NEWPAGE.Pr1 = page.Pr4
        NEWPAGE.P2 = page.P5
        NEWPAGE.C2 = KEY
        NEWPAGE.Pr2 = PON
        NEWPAGE.P3 = -1

        fseek(ARQ, 0, SEEK_END);
        fwrite(NEWPAGE.C1, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr1, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.C2, sizeof(int), 1, ARQ);
        fwrite(NEWPAGE.Pr2, sizeof(long long), 1, ARQ);
        fwrite(NEWPAGE.P3, sizeof(int), 1, ARQ);
    }
}*/

int insert(int CURRENT_RRN, int KEY, long long PON, FILE *arq){
    tree_page page;
    tree_header header, h;

    if (CURRENT_RRN == -1){
        //corrige as infos da arvore
        header.noRaiz = 0;
        header.RRNproxNo = 1;

        //cria uma pagina
        page.folha = '1';
        page.nroChavesIndexadas = 1;
        page.RRNdoNo = header.noRaiz;
        page.P1 = -1;
        page.C1 = KEY;
        page.Pr1 = PON;
        page.P2 = -1;
        page.C2 = -1;
        page.Pr2 = -1;
        page.P3 = -1;
        page.C3 = -1;
        page.Pr3 = -1;
        page.P4 = -1;
        page.C4 = -1;
        page.Pr4 = -1;
        page.P5 = -1;

        //insere no arquivo
        fseek(arq, 1, SEEK_SET);
        fwrite(&header.noRaiz, sizeof(int), 1, arq);
        fwrite(&header.RRNproxNo, sizeof(int), 1, arq);

        fseek(arq, 68, SEEK_CUR);

        fwrite(&page.folha, sizeof(char), 1, arq);
        fwrite(&page.nroChavesIndexadas, sizeof(int), 1, arq);
        fwrite(&page.RRNdoNo, sizeof(int), 1, arq);
        fwrite(&page.P1, sizeof(int), 1, arq);
        fwrite(&page.C1, sizeof(int), 1, arq);
        fwrite(&page.Pr1, sizeof(long long), 1, arq);
        fwrite(&page.P2, sizeof(int), 1, arq);
        fwrite(&page.C2, sizeof(int), 1, arq);
        fwrite(&page.Pr2, sizeof(long long), 1, arq);
        fwrite(&page.P3, sizeof(int), 1, arq);
        fwrite(&page.C3, sizeof(int), 1, arq);
        fwrite(&page.Pr3, sizeof(long long), 1, arq);
        fwrite(&page.P4, sizeof(int), 1, arq);
        fwrite(&page.C4, sizeof(int), 1, arq);
        fwrite(&page.Pr4, sizeof(long long), 1, arq);
        fwrite(&page.P5, sizeof(int), 1, arq);

        return 1;
    }      
    else{ 
        fseek(arq, (CURRENT_RRN+1)*TREE_LENGTH, SEEK_SET);

        fread(&page.folha, sizeof(char), 1, arq);
        fread(&page.nroChavesIndexadas, sizeof(int), 1, arq);
        fread(&page.RRNdoNo, sizeof(int), 1, arq);
        fread(&page.P1, sizeof(int), 1, arq);
        fread(&page.C1, sizeof(int), 1, arq);
        fread(&page.Pr1, sizeof(long long), 1, arq);
        fread(&page.P2, sizeof(int), 1, arq);
        fread(&page.C2, sizeof(int), 1, arq);
        fread(&page.Pr2, sizeof(long long), 1, arq);
        fread(&page.P3, sizeof(int), 1, arq);
        fread(&page.C3, sizeof(int), 1, arq);
        fread(&page.Pr3, sizeof(long long), 1, arq);
        fread(&page.P4, sizeof(int), 1, arq);
        fread(&page.C4, sizeof(int), 1, arq);
        fread(&page.Pr4, sizeof(long long), 1, arq);
        fread(&page.P5, sizeof(int), 1, arq);
        
        if ((KEY == page.C1) || ((KEY == page.C2) && (page.nroChavesIndexadas > 1)) || ((KEY == C3) && (page.nroChavesIndexadas > 2)) || ((KEY == C4) && (page.nroChavesIndexadas > 3))){
            raise_error("");
            return -1
        }
        else if (KEY < page.C1){
            RETURN_VALUE = insert (page.P1, KEY, PROMO_R_CHILD, PROMO_KEY, PON, ARQ)
        }
        else if ((page.C1 < KEY) && ( ((KEY < page.C2) && (page.nroChavesIndexadas > 1)) || ((page.nroChavesIndexadas == 1)))){
            RETURN_VALUE = insert (page.P2, KEY, PROMO_R_CHILD, PROMO_KEY, PON, ARQ)
        }
        else if ((page.C2 < KEY) && ( ((KEY < page.C3) && (page.nroChavesIndexadas > 2)) || ((page.nroChavesIndexadas == 2)))){
            RETURN_VALUE = insert (page.P3, KEY, PROMO_R_CHILD, PROMO_KEY, PON, ARQ)
        }
        else if ((page.C3 < KEY) && ( ((KEY < page.C4) && (page.nroChavesIndexadas > 3)) || ((page.nroChavesIndexadas == 3)))){
            RETURN_VALUE = insert (page.P4, KEY, PROMO_R_CHILD, PROMO_KEY, PON, ARQ)
        }
        else if(page.C4 < KEY && (page.nroChavesIndexadas == 4)){
            RETURN_VALUE = insert (page.P4, KEY, PROMO_R_CHILD, PROMO_KEY, PON, ARQ)
        }

        if ((RETURN_VALUE == 0) or (RETURN_VALUE == -1)){
            return RETURN_VALUE
        }
        else if (page.nroChavesIndexadas < 4){
            if(KEY < C1){
                page.nroChavesIndexadas++; 
                page.P5 = page.P4;
                page.C4 = page.C3;
                page.Pr4 = page.Pr3;
                page.P4 = page.P3;
                page.C3 = page.C2;
                page.Pr3 = page.Pr2;
                page.P3 = page.P2;
                page.C2 = page.C1;
                page.Pr2 = page.Pr1;
                page.P2 = page.P1;
                page.C1 = KEY;
                page.Pr1 = PON;
                page.P1 = -1;

                fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
                fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
                fseek(ARQ, 4, SEEK_CUR);
                fwrite(page.P1, sizeof(int), 1, ARQ);
                fwrite(page.C1, sizeof(int), 1, ARQ);
                fwrite(page.Pr1, sizeof(long long), 1, ARQ);
                fwrite(page.P2, sizeof(int), 1, ARQ);
                fwrite(page.C2, sizeof(int), 1, ARQ);
                fwrite(page.Pr2, sizeof(long long), 1, ARQ);
                fwrite(page.P3, sizeof(int), 1, ARQ);
                fwrite(page.C3, sizeof(int), 1, ARQ);
                fwrite(page.Pr3, sizeof(long long), 1, ARQ);
                fwrite(page.P4, sizeof(int), 1, ARQ);
                fwrite(page.C4, sizeof(int), 1, ARQ);
                fwrite(page.Pr4, sizeof(long long), 1, ARQ);
                fwrite(page.P5, sizeof(int), 1, ARQ);
            }
            else if((page.C1 < KEY) && ( ((KEY < page.C2) && (page.nroChavesIndexadas > 1)) || ((page.nroChavesIndexadas == 1)))){
                page.nroChavesIndexadas++; 
                page.P5 = page.P4;
                page.C4 = page.C3;
                page.Pr4 = page.Pr3;
                page.P4 = page.P3;
                page.C3 = page.C2;
                page.Pr3 = page.Pr2;
                page.P3 = page.P2;
                page.C2 = KEY
                page.Pr2 = PON;
                page.P2 = -1;

                fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
                fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
                fseek(ARQ, 20, SEEK_CUR);
                fwrite(page.P2, sizeof(int), 1, ARQ);
                fwrite(page.C2, sizeof(int), 1, ARQ);
                fwrite(page.Pr2, sizeof(long long), 1, ARQ);
                fwrite(page.P3, sizeof(int), 1, ARQ);
                fwrite(page.C3, sizeof(int), 1, ARQ);
                fwrite(page.Pr3, sizeof(long long), 1, ARQ);
                fwrite(page.P4, sizeof(int), 1, ARQ);
                fwrite(page.C4, sizeof(int), 1, ARQ);
                fwrite(page.Pr4, sizeof(long long), 1, ARQ);
                fwrite(page.P5, sizeof(int), 1, ARQ);
            }
            else if((page.C2 < KEY) && ( ((KEY < page.C3) && (page.nroChavesIndexadas > 2)) || ((page.nroChavesIndexadas == 2)))){
                page.nroChavesIndexadas++; 
                page.P5 = page.P4;
                page.C4 = page.C3;
                page.Pr4 = page.Pr3;
                page.P4 = page.P3;
                page.C3 = KEY;
                page.Pr3 = PON;
                page.P3 = -1;

                fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
                fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
                fseek(ARQ, 36, SEEK_CUR);
                fwrite(page.P3, sizeof(int), 1, ARQ);
                fwrite(page.C3, sizeof(int), 1, ARQ);
                fwrite(page.Pr3, sizeof(long long), 1, ARQ);
                fwrite(page.P4, sizeof(int), 1, ARQ);
                fwrite(page.C4, sizeof(int), 1, ARQ);
                fwrite(page.Pr4, sizeof(long long), 1, ARQ);
                fwrite(page.P5, sizeof(int), 1, ARQ);
            }
            else if((page.C3 < KEY) && ( ((KEY < page.C4) && (page.nroChavesIndexadas > 3)) || ((page.nroChavesIndexadas == 3)))){
                page.nroChavesIndexadas++; 
                page.P5 = page.P4;
                page.C4 = page.C3;
                page.Pr4 = page.Pr3;
                page.P4 = page.P3;
                page.C3 = KEY;
                page.Pr3 = PON;
                page.P3 = -1;

                fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
                fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
                fseek(ARQ, 36, SEEK_CUR);
                fwrite(page.P3, sizeof(int), 1, ARQ);
                fwrite(page.C3, sizeof(int), 1, ARQ);
                fwrite(page.Pr3, sizeof(long long), 1, ARQ);
                fwrite(page.P4, sizeof(int), 1, ARQ);
                fwrite(page.C4, sizeof(int), 1, ARQ);
                fwrite(page.Pr4, sizeof(long long), 1, ARQ);
                fwrite(page.P5, sizeof(int), 1, ARQ);
            }
            else if(page.C3 < KEY){
                page.nroChavesIndexadas++; 
                page.P5 = page.P4;
                page.C4 = KEY;
                page.Pr4 = PON;
                page.P4 = -1;

                fseek(ARQ, CURRENT_RRN+1, SEEK_SET);
                fwrite(page.nroChavesIndexadas, sizeof(int), 1, ARQ);
                fseek(ARQ, 52, SEEK_CUR);
                fwrite(page.P4, sizeof(int), 1, ARQ);
                fwrite(page.C4, sizeof(int), 1, ARQ);
                fwrite(page.Pr4, sizeof(long long), 1, ARQ);
                fwrite(page.P5, sizeof(int), 1, ARQ);
            }

            return NO_PROMOTION
        }
        else{
            //split(KEY, I_RRN, CURRENT_RRN, PROMO_KEY, PROMO_R_CHILD, NEWPAGE, PON)

            return PROMOTION
        }
    }
}

/*void create_tree_vehicle(char *arquivoVeiculo, char *arquivoArvore){
	FILE *arq1, *arq2;
	vehicle_header header;
    vehicle_register data;
    tree_header headerT; // = (tree_header *)malloc(sizeof(tree_header));
    tree_page page;
    int prefixo_int;

    headerT.status = "0";
    headerT.noRaiz = -1;
    header.RRNproxNo = 1; 
    for(int i = 0; i < 68; i++){
    	header.lixo[i] = "@"
    }

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "wb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }

	// if the file is inconsistent, raise error
    fread(&header.status, sizeof(char), 1, arq1);
    if(header.status == '0'){ raise_error(""); }

    // reads the header's byteProxReg and nroRegistros
    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
    fread(&header.nroRegistros, sizeof(int), 1, arq1);

    // if there are no registers, raises error
    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

    // reads the header's remaining fields
    // fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
    // fread(header.descrevePrefixo, sizeof(char), 18, arq1);
    // fread(header.descreveData, sizeof(char), 35, arq1);
    // fread(header.descreveLugares, sizeof(char), 42, arq1);
    // fread(header.descreveLinha, sizeof(char), 26, arq1);
    // fread(header.descreveModelo, sizeof(char), 17, arq1);
    // fread(header.descreveCategoria, sizeof(char), 20, arq1);
    fseek(arq1, 162, SEEK_CUR);


    //insere o cabeçalho da arvore
    fwrite(headerT.status, sizeof(char), 1, arq2);
    fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);
    fwrite(headerT.lixo, sizeof(char), 68, arq2);


    // reads and inserts each register
    int index = 0;
    while(index < header.nroRegistros){
        // reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // if the current register was removed, it'll not be inserted
        if(data.removido == '0'){ 
            fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
            continue; 
        }

        // reads the current register's remaining fixed size fields
        // fread(data.prefixo, sizeof(char), 5, arq1);
        // fread(data.data, sizeof(char), 10, arq1);
        // fread(&data.quantidadeLugares, sizeof(int), 1, arq1);
        // fread(&data.codLinha, sizeof(int), 1, arq1);

        // // reads the current register's "modelo" field (variable size)
        // fread(&data.tamanhoModelo, sizeof(int), 1, arq1);
        // data.modelo = (char *)malloc(sizeof(char) * data.tamanhoModelo);
        // fread(data.modelo, sizeof(char), data.tamanhoModelo, arq1);

        // // reads the current register's "categoria" field (variable size)
        // fread(&data.tamanhoCategoria, sizeof(int), 1, arq1);
        // data.categoria = (char *)malloc(sizeof(char) * data.tamanhoCategoria);
        // fread(data.categoria, sizeof(char), data.tamanhoCategoria, arq1);

        // // gets formatted date or null message
        // char *date = data.data[0] != '\0' ? format_date(data.data) : "campo com valor nulo";
        fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
        

        // insere no arquivo 2 a arvore
        prefixo_int = convertePrefixo(data.prefixo);

        // PROMO_R_CHILD E PROMO_KEY E PON (?)
        insert(headerT.noRaiz, prefixo_int, PROMO_R_CHILD, PROMO_KEY, PON, arq2);

        //atualizar o headerT.noRaiz
        fseek(arq2, 1, SEEK_SET);
        headerT.noRaiz = PROMO_R_CHILD; //(?)
        headerT.RRNproxNo = PROMO_R_CHILD + 1; //(?) 
    	fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    	fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);


        // frees allocated strings
        // free(data.modelo);
        // free(data.categoria);

        // increments index
        index++;
    }


    // MUDAR O STATUS PARA 1
    fseek(arq1, 0, SEEK_SET);
    headerT.status = "1";
    fwrite(headerT.status, sizeof(char), 1, arq2);


    fclose(arq1);
    fclose(arq2);
}

void create_tree_line(char *arquivoVeiculo, char *arquivoArvore){
	FILE *arq1, *arq2;
	line_header header;
    line_register data;
    tree_header headerT; // = (tree_header *)malloc(sizeof(tree_header));
    tree_page page;
    int prefixo_int;

    headerT.status = "0";
    headerT.noRaiz = -1;
    header.RRNproxNo = 1; 
    for(int i = 0; i < 68; i++){
    	header.lixo[i] = "@"
    }

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "wb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }

	// if the file is inconsistent, raise error
    fread(&header.status, sizeof(char), 1, arq1);
    if(header.status == '0'){ raise_error(""); }

    // reads the header's byteProxReg and nroRegistros
    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
    fread(&header.nroRegistros, sizeof(int), 1, arq1);

    // if there are no registers, raises error
    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

    // reads the header's remaining fields
    // fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
    // fread(header.descreveCodigo, sizeof(char), 15, arq1);
    // fread(header.descreveCartao, sizeof(char), 13, arq1);
    // fread(header.descreveNome, sizeof(char), 13, arq1);
    // fread(header.descreveCor, sizeof(char), 24, arq1);
    fseek(arq1, 69, SEEK_CUR);

    //insere o cabeçalho da arvore
    fwrite(headerT.status, sizeof(char), 1, arq2);
    fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);
    fwrite(headerT.lixo, sizeof(char), 68, arq2);


    // reads and prints each register
    int index = 0;
    while(index < header.nroRegistros){
        // reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // if the current register was removed, it'll not be printed
        if(data.removido == '0'){ 
            fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
            continue; 
        }

        // reads the current register's remaining fixed size fields
        // fread(&data.codLinha, sizeof(int), 1, arq1);
        // fread(&data.aceitaCartao, sizeof(char), 1, arq1);

        // // reads the current register's "nomeLinha" field (variable size)
        // fread(&data.tamanhoNome, sizeof(int), 1, arq1);
        // data.nomeLinha = (char *)malloc(sizeof(char) * data.tamanhoNome);
        // fread(data.nomeLinha, sizeof(char), data.tamanhoNome, arq1);

        // // reads the current register's "corLinha" field (variable size)
        // fread(&data.tamanhoCor, sizeof(int), 1, arq1);
        // data.corLinha = (char *)malloc(sizeof(char) * data.tamanhoCor);
        // fread(data.corLinha, sizeof(char), data.tamanhoCor, arq1);
        fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
        


        // PROMO_R_CHILD E PROMO_KEY (?)
        insert(headerT.noRaiz, data.codLinha, PROMO_R_CHILD, PROMO_KEY, PON, arq2);

        //atualizar o headerT.noRaiz
        fseek(arq2, 1, SEEK_SET);
        headerT.noRaiz = PROMO_R_CHILD; //(?)
        headerT.RRNproxNo = PROMO_R_CHILD + 1; //(?) 
    	fwrite(headerT.noRaiz, sizeof(int), 1, arq2);
    	fwrite(headerT.RRNproxNo, sizeof(int), 1, arq2);


        // frees allocated strings
        // free(data.nomeLinha);
        // free(data.corLinha);

        // increments index
        index++;
    }


    // MUDAR O STATUS PARA 1
    fseek(arq1, 0, SEEK_SET);
    headerT.status = "1";
    fwrite(headerT.status, sizeof(char), 1, arq2);


    fclose(arq1);
    fclose(arq2);
}

void search_tree_vehicle(char *arquivoVeiculo, char *arquivoArvore, char *prefixo, char *valor){
	//converte prefixo para poder encontrar a chave
	// A manipulação do arquivo de índice árvore-B deve ser feita em disco, de acordo com o conteúdo ministrado em sala de aula.
	//Falha no processamento do arquivo.

	FILE *arq1, *arq2;
	vehicle_header header;
    vehicle_register data;
    tree_header headerT;
    int valor_int;

    valor_int = convertePrefixo(valor);

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "rb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }


	// procura na arvore
	fread(&headerT.status, sizeof(char), 1, arq2);
    if(headerT.status == '0'){ raise_error(""); }

    fread(&header.noRaiz, sizeof(int), 1, arq2);
    
	if(search(header.noRaiz, valor_int, achou_RRN, achou_POS, achou_Pr, arq2)){
		// if the file is inconsistent, raise error
	    fread(&header.status, sizeof(char), 1, arq1);
	    if(header.status == '0'){ raise_error(""); }

	    // reads the header's byteProxReg and nroRegistros
	    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
	    fread(&header.nroRegistros, sizeof(int), 1, arq1);

	    // if there are no registers, raises error
	    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

	    // reads the header's remaining fields
	    fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
	    fread(header.descrevePrefixo, sizeof(char), 18, arq1);
	    fread(header.descreveData, sizeof(char), 35, arq1);
	    fread(header.descreveLugares, sizeof(char), 42, arq1);
	    fread(header.descreveLinha, sizeof(char), 26, arq1);
	    fread(header.descreveModelo, sizeof(char), 17, arq1);
	    fread(header.descreveCategoria, sizeof(char), 20, arq1);

		fseek(arq1, achou_Pr, SEEK_SET);

		// reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // reads the current register's remaining fixed size fields
        fread(data.prefixo, sizeof(char), 5, arq1);
        fread(data.data, sizeof(char), 10, arq1);
        fread(&data.quantidadeLugares, sizeof(int), 1, arq1);
        fread(&data.codLinha, sizeof(int), 1, arq1);

        // reads the current register's "modelo" field (variable size)
        fread(&data.tamanhoModelo, sizeof(int), 1, arq1);
        data.modelo = (char *)malloc(sizeof(char) * data.tamanhoModelo);
        fread(data.modelo, sizeof(char), data.tamanhoModelo, arq1);

        // reads the current register's "categoria" field (variable size)
        fread(&data.tamanhoCategoria, sizeof(int), 1, arq1);
        data.categoria = (char *)malloc(sizeof(char) * data.tamanhoCategoria);
        fread(data.categoria, sizeof(char), data.tamanhoCategoria, arq1);

		// gets formatted date or null message
        char *date = data.data[0] != '\0' ? format_date(data.data) : "campo com valor nulo";
        
        // prints the current register's fields
        print_string_field(header.descrevePrefixo, 18, data.prefixo, 5);
        print_string_field(header.descreveModelo, 17, data.modelo, data.tamanhoModelo);
        print_string_field(header.descreveCategoria, 20, data.categoria, data.tamanhoCategoria);
        print_string_field(header.descreveData, 35, date, strlen(date));
        print_int_field(header.descreveLugares, 42, data.quantidadeLugares);

        // prints newline
        printf("\n");

        // frees allocated strings
        free(data.modelo);
        free(data.categoria);
        if(data.data[0] != '\0' ){ free(date); }
	}
	else{
		printf("Registro inexistente.\n");
	}

    fclose(arq1);
    fclose(arq2);
}

void search_tree_line(char *arquivoVeiculo, char *arquivoArvore, char *prefixo, int valor){
	// A manipulação do arquivo de índice árvore-B deve ser feita em disco, de acordo com o conteúdo ministrado em sala de aula.
	//Falha no processamento do arquivo.

	FILE *arq1, *arq2;
	line header;
    line_register data;
    tree_header headerT;

    // opens the file in arq1-reading mode
	arq1 = fopen(arquivoVeiculo, "rb");
	arq2 = fopen(arquivoArvore, "wb");

	// if the file does not exist, raise error
	if((arq1 == NULL) || (arq2 == NULL)){ raise_error(""); }


	// procura na arvore
	fread(&headerT.status, sizeof(char), 1, arq2);
    if(headerT.status == '0'){ raise_error(""); }

    fread(&header.noRaiz, sizeof(int), 1, arq2);

	if(search(header.noRaiz, valor_int, achou_RRN, achou_POS, achou_Pr, arq2)){
		// if the file is inconsistent, raise error
	    fread(&header.status, sizeof(char), 1, arq1);
	    if(header.status == '0'){ raise_error(""); }

	    // reads the header's byteProxReg and nroRegistros
	    fread(&header.byteProxReg, sizeof(long long), 1, arq1);
	    fread(&header.nroRegistros, sizeof(int), 1, arq1);

	    // if there are no registers, raises error
	    if(!header.nroRegistros){ raise_error("Registro inexistente."); }

	    // reads the header's remaining fields
	    fread(&header.nroRegRemovidos, sizeof(int), 1, arq1);
	    fread(header.descreveCodigo, sizeof(char), 15, arq1);
	    fread(header.descreveCartao, sizeof(char), 13, arq1);
	    fread(header.descreveNome, sizeof(char), 13, arq1);
	    fread(header.descreveCor, sizeof(char), 24, arq1);

		fseek(arq1, achou_Pr, SEEK_SET);

		// reads the current register's "removido" and "tamanhoRegistro" fields
        fread(&data.removido, sizeof(char), 1, arq1);
        fread(&data.tamanhoRegistro, sizeof(int), 1, arq1);

        // if the current register was removed, it'll not be printed
        if(data.removido == '0'){ 
            fseek(arq1, data.tamanhoRegistro, SEEK_CUR);
            continue; 
        }

        // reads the current register's remaining fixed size fields
        fread(&data.codLinha, sizeof(int), 1, arq1);
        fread(&data.aceitaCartao, sizeof(char), 1, arq1);

        // reads the current register's "nomeLinha" field (variable size)
        fread(&data.tamanhoNome, sizeof(int), 1, arq1);
        data.nomeLinha = (char *)malloc(sizeof(char) * data.tamanhoNome);
        fread(data.nomeLinha, sizeof(char), data.tamanhoNome, arq1);

        // reads the current register's "corLinha" field (variable size)
        fread(&data.tamanhoCor, sizeof(int), 1, arq1);
        data.corLinha = (char *)malloc(sizeof(char) * data.tamanhoCor);
        fread(data.corLinha, sizeof(char), data.tamanhoCor, arq1);
        
        // gets formatted card status
        char *card_status = format_card(data.aceitaCartao);

        // prints the current register's fields
        print_int_field(header.descreveCodigo, 15, data.codLinha);
        print_string_field(header.descreveNome, 13, data.nomeLinha, data.tamanhoNome);
        print_string_field(header.descreveCor, 24, data.corLinha, data.tamanhoCor);
        print_string_field(header.descreveCartao, 13, card_status, strlen(card_status));

        // prints newline
        printf("\n");

        // frees allocated strings
        free(data.nomeLinha);
        free(data.corLinha);
	}
	else{
		printf("Registro inexistente.\n");
	}

    fclose(arq1);
    fclose(arq2);
}*/
